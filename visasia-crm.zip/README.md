# VisAsia CRM

## Запуск локально

```bash
npm install
npm run db:seed
npm run dev
```

Открыть: http://localhost:3000

## Тестовые пользователи

- Руководитель: `director@visasia.kz` / `123456`
- Админ: `admin@visasia.kz` / `123456`
- Менеджер Динара: `dinara@visasia.kz` / `123456`
- Менеджер Руслан: `ruslan@visasia.kz` / `123456`
- Менеджер Мадина: `madina@visasia.kz` / `123456`

## Роли

- `owner`: видит всех клиентов, сделки, оплаты, задачи, менеджеров и настройки.
- `admin`: видит все данные и может управлять настройками/менеджерами.
- `manager`: видит только своих клиентов, сделки, задачи и оплаты.

## Важно перед production

- Сменить `AUTH_SECRET`.
- Заменить тестовые пароли.
- Подключить PostgreSQL на Railway/Supabase перед рабочим запуском.
